import React, { useState } from 'react';
import axios from 'axios';

function Register() {
  const [fullName, setFullName] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    try {
      const response = await axios.post('http://localhost:5000/api/customers/register', {
        fullName,
        idNumber,
        accountNumber,
        password,
      });

      if (response && response.data) {
        setMessage(response.data.message);
      } else {
        setError('Unexpected response format');
      }

      setFullName('');
      setIdNumber('');
      setAccountNumber('');
      setPassword('');
    } catch (error) {
      if (error.response && error.response.data && error.response.data.errors) {
        setError(error.response.data.errors.map(err => err.msg).join(', '));
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    }
  };

  const styles = {
    container: {
      maxWidth: '400px',
      margin: '50px auto',
      padding: '20px',
      border: '1px solid #ccc',
      borderRadius: '8px',
      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
      backgroundColor: '#f9f9f9',
    },
    heading: {
      textAlign: 'center',
      color: '#333',
      marginBottom: '20px',
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
    },
    input: {
      marginBottom: '15px',
      padding: '10px',
      border: '1px solid #ccc',
      borderRadius: '5px',
      fontSize: '16px',
    },
    inputFocus: {
      borderColor: '#007bff',
      outline: 'none',
    },
    button: {
      padding: '10px',
      border: 'none',
      borderRadius: '5px',
      backgroundColor: '#007bff',
      color: 'white',
      fontSize: '16px',
      cursor: 'pointer',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
    message: {
      textAlign: 'center',
      marginTop: '10px',
    },
    successMessage: {
      color: 'green',
    },
    errorMessage: {
      color: 'red',
    },
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Register</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <input 
          style={styles.input}
          type="text" 
          placeholder="Full Name" 
          value={fullName} 
          onChange={(e) => setFullName(e.target.value)} 
          required 
        />
        <input 
          style={styles.input}
          type="text" 
          placeholder="ID Number" 
          value={idNumber} 
          onChange={(e) => setIdNumber(e.target.value)} 
          required 
        />
        <input 
          style={styles.input}
          type="number" 
          placeholder="Account Number" 
          value={accountNumber} 
          onChange={(e) => setAccountNumber(e.target.value)} 
          required 
        />
        <input 
          style={styles.input}
          type="password" 
          placeholder="Password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required 
        />
        <button type="submit" style={styles.button}>Register</button>
        
        {message && <p style={{ ...styles.message, ...styles.successMessage }}>{message}</p>}
        {error && <p style={{ ...styles.message, ...styles.errorMessage }}>{error}</p>}
      </form>
    </div>
  );
}

export default Register;
