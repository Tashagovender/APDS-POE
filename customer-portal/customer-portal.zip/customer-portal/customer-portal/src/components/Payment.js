import React, { useState } from 'react';
import axios from 'axios';

function Payment() {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('');
  const [payeeAccount, setPayeeAccount] = useState('');
  const [swiftCode, setSwiftCode] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    try {
      const token = localStorage.getItem('jwtToken');

      const response = await axios.post('http://localhost:5000/api/pay', {
        amount,
        currency,
        payeeAccount,
        swiftCode,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setMessage('Payment processed successfully!');
      console.log(response.data);
    } catch (error) {
      setError(error.response.data.message || 'Payment failed. Please try again.');
      console.error(error.response.data);
    }
  };

  // Styles
  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
      textAlign: 'center',
      backgroundColor: '#f9f9f9',
      borderRadius: '8px',
      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    },
    heading: {
      color: '#333',
      marginBottom: '20px',
    },
    input: {
      display: 'block',
      width: '100%',
      padding: '10px',
      margin: '10px 0',
      borderRadius: '5px',
      border: '1px solid #ccc',
      fontSize: '16px',
    },
    button: {
      backgroundColor: '#007bff',
      color: 'white',
      padding: '10px 15px',
      border: 'none',
      borderRadius: '5px',
      cursor: 'pointer',
      fontSize: '16px',
      marginTop: '10px',
    },
    buttonHover: {
      backgroundColor: '#0056b3',
    },
    message: {
      color: 'green',
    },
    error: {
      color: 'red',
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Payment Form</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Currency"
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Payee Account"
          value={payeeAccount}
          onChange={(e) => setPayeeAccount(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="text"
          placeholder="SWIFT Code"
          value={swiftCode}
          onChange={(e) => setSwiftCode(e.target.value)}
          required
          style={styles.input}
        />
        <button type="submit" style={styles.button}>Pay</button>

        {message && <p style={styles.message}>{message}</p>}
        {error && <p style={styles.error}>{error}</p>}
      </form>
    </div>
  );
}

export default Payment;
