import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [accountNumber, setAccountNumber] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validate account number length
    if (accountNumber.length !== 10) {
      setError('Account Number must be exactly 10 digits.');
      setLoading(false);
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/api/customers/login', {
        accountNumber,
        password,
      });
      const { token } = response.data;
      localStorage.setItem('jwtToken', token);
      console.log(response.data);
      // Navigate to the payment page upon successful login
      navigate('/payment');
    } catch (error) {
      setError(error.response?.data?.message || 'Login failed. Please try again.');
      console.error(error.response?.data); // Log error
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    container: {
      maxWidth: '400px',
      margin: '0 auto',
      padding: '20px',
      borderRadius: '8px',
      backgroundColor: '#f9f9f9',
      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
      textAlign: 'center',
    },
    input: {
      width: '100%',
      padding: '10px',
      margin: '10px 0',
      borderRadius: '4px',
      border: '1px solid #ccc',
      fontSize: '16px',
    },
    button: {
      backgroundColor: '#007bff',
      color: '#fff',
      padding: '10px',
      border: 'none',
      borderRadius: '4px',
      fontSize: '16px',
      cursor: 'pointer',
      width: '100%',
    },
    buttonDisabled: {
      backgroundColor: '#ccc',
      cursor: 'not-allowed',
    },
    message: {
      color: 'red',
      marginTop: '10px',
    },
    loading: {
      fontSize: '16px',
      color: '#007bff',
    },
  };

  return (
    <div style={styles.container}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Account Number"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={styles.input}
        />
        <button 
          type="submit" 
          style={{ 
            ...styles.button, 
            ...(loading ? styles.buttonDisabled : {}) 
          }} 
          disabled={loading}
        >
          {loading ? 'Logging in...' : 'Login'}
        </button>
        {loading && <p style={styles.loading}>Loading...</p>}
        {error && <p style={styles.message}>{error}</p>} {/* Display error messages */}
      </form>
    </div>
  );
}

export default Login;
