import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Payment from './components/Payment';

function App() {
  const styles = {
    container: {
      maxWidth: '800px',
      margin: '50px auto', // Increased margin for better spacing
      padding: '30px',
      textAlign: 'center',
      backgroundColor: '#acc5c9', // Updated background color
      borderRadius: '10px',
      boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)', // Slightly deeper shadow for depth
      border: '1px solid #2e2e2e', // Added border for seriousness
    },
    heading: {
      color: '#2e2e2e', // Darker color for heading
      marginBottom: '20px',
      fontSize: '24px', // Increased font size for prominence
    },
    paragraph: {
      fontSize: '18px',
      color: '#444', // Slightly darker color for better readability
      marginBottom: '30px', // Added margin for spacing
    },
    link: {
      color: '#0056b3', // Changed link color for a more serious look
      textDecoration: 'none',
      margin: '0 10px',
      fontWeight: 'bold',
    },
    linkHover: {
      textDecoration: 'underline',
    },
  };

  return (
    <Router>
      <div style={styles.container}>
        <h1 style={styles.heading}>Welcome to the Customer Portal</h1>
        <p style={styles.paragraph}>
          Please navigate to 
          <Link to="/register" style={styles.link}> Register</Link> 
          or 
          <Link to="/login" style={styles.link}> Login</Link>.
        </p>
        <Routes>
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/payment" element={<Payment />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
